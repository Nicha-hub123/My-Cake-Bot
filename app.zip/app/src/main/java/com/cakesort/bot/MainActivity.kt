package com.cakesort.bot

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.cakesort.bot.service.FloatingOverlayService

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatusLog: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate()
        setContentView(R.layout.activity_main)

        tvStatusLog = findViewById(R.id.tvStatusLog)
        val btnOverlay = findViewById<Button>(R.id.btnOverlayPermission)
        val btnAccessibility = findViewById<Button>(R.id.btnAccessibilityPermission)
        val btnStartOverlay = findViewById<Button>(R.id.btnStartOverlay)

        btnOverlay.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                log("Opened Overlay Permission Settings.")
            } else {
                Toast.makeText(this, "Overlay Permission already granted!", Toast.LENGTH_SHORT).show()
                log("Overlay permission active.")
            }
        }

        btnAccessibility.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            log("Opened Accessibility Settings. Enable 'Cake Sort Auto Bot Service'.")
        }

        btnStartOverlay.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Please grant Overlay Permission first!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val intent = Intent(this, FloatingOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            log("Started Floating Overlay Widget Service.")
            Toast.makeText(this, "Floating Bot HUD active! Switch to your game.", Toast.LENGTH_LONG).show()
        }
    }

    private fun log(message: String) {
        tvStatusLog.append("\n> $message")
    }
}