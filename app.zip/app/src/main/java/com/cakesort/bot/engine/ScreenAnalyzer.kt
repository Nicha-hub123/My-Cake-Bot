package com.cakesort.bot.engine

import android.graphics.Bitmap
import android.graphics.Color
import com.cakesort.bot.model.CakePlate

class ScreenAnalyzer {

    // Analyze RGB values on specific coordinates to classify cake colors
    fun extractBoardState(bitmap: Bitmap, width: Int, height: Int): List<CakePlate?> {
        val boardState = MutableList<CakePlate?>(20) { null }
        
        // Grid mapping ratios for 4 cols x 5 rows
        val startXRatio = 0.18f
        val stepXRatio = 0.21f
        val startYRatio = 0.15f
        val stepYRatio = 0.11f

        var slotIdx = 0
        for (row in 0 until 5) {
            for (col in 0 until 4) {
                val cx = (width * (startXRatio + col * stepXRatio)).toInt()
                val cy = (height * (startYRatio + row * stepYRatio)).toInt()

                if (cx in 0 until width && cy in 0 until height) {
                    val pixel = bitmap.getPixel(cx, cy)
                    if (!isBackgroundSlot(pixel)) {
                        val flavorId = classifyColor(pixel)
                        boardState[slotIdx] = CakePlate(slotIdx, listOf(flavorId))
                    }
                }
                slotIdx++
            }
        }
        return boardState
    }

    fun extractDockState(bitmap: Bitmap, width: Int, height: Int): List<CakePlate?> {
        val dockState = MutableList<CakePlate?>(4) { null }
        val startXRatio = 0.20f
        val stepXRatio = 0.20f
        val dockYRatio = 0.85f

        val cy = (height * dockYRatio).toInt()
        for (i in 0 until 4) {
            val cx = (width * (startXRatio + i * stepXRatio)).toInt()
            if (cx in 0 until width && cy in 0 until height) {
                val pixel = bitmap.getPixel(cx, cy)
                if (!isBackgroundSlot(pixel)) {
                    val flavorId = classifyColor(pixel)
                    dockState[i] = CakePlate(i, listOf(flavorId))
                }
            }
        }
        return dockState
    }

    private fun isBackgroundSlot(pixel: Int): Boolean {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        // Dark metallic background threshold
        return (r < 40 && g < 50 && b < 65)
    }

    private fun classifyColor(pixel: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(pixel, hsv)
        val hue = hsv[0]

        return when {
            hue in 340.0f..360.0f || hue in 0.0f..20.0f -> 1 // Red / Strawberry
            hue in 80.0f..160.0f -> 2                        // Green / Matcha
            hue in 260.0f..310.0f -> 3                       // Purple / Chocolate
            hue in 35.0f..75.0f -> 4                         // Yellow / Lemon
            hue in 190.0f..250.0f -> 5                       // Blue / Blueberry
            else -> 6                                        // Orange / Other
        }
    }
}