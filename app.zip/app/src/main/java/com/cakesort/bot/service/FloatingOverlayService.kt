package com.cakesort.bot.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.cakesort.bot.R
import com.cakesort.bot.engine.CakeSolverEngine
import com.cakesort.bot.engine.ScreenAnalyzer
import com.cakesort.bot.model.CakePlate

class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private val solverEngine = CakeSolverEngine()
    private val screenAnalyzer = ScreenAnalyzer()

    private var isAutoRunning = false
    private val handler = Handler(Looper.getMainLooper())
    private var autoRunnable: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundServiceNotification()
        setupFloatingWindow()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "cake_bot_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Cake Sort Bot Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Cake Sort AI Bot Active")
            .setContentText("Floating overlay helper is running over game.")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()

        startForeground(101, notification)
    }

    private fun setupFloatingWindow() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_widget, null)

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        windowManager.addView(floatingView, layoutParams)

        val btnStep = floatingView.findViewById<Button>(R.id.btnStepAi)
        val btnAuto = floatingView.findViewById<Button>(R.id.btnAutoToggle)
        val btnClose = floatingView.findViewById<Button>(R.id.btnCloseWidget)
        val tvStatus = floatingView.findViewById<TextView>(R.id.tvStatus)

        // Drag floating window gesture
        floatingView.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        layoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(floatingView, layoutParams)
                        return true
                    }
                }
                return false
            }
        })

        btnStep.setOnClickListener {
            executeSingleBotMove(tvStatus)
        }

        btnAuto.setOnClickListener {
            isAutoRunning = !isAutoRunning
            if (isAutoRunning) {
                btnAuto.text = "Auto: ON"
                btnAuto.setBackgroundColor(android.graphics.Color.RED)
                tvStatus.text = "Status: Auto Bot Running"
                startAutoLoop(tvStatus)
            } else {
                btnAuto.text = "Auto: OFF"
                btnAuto.setBackgroundColor(android.graphics.Color.parseColor("#10B981"))
                tvStatus.text = "Status: Paused"
                stopAutoLoop()
            }
        }

        btnClose.setOnClickListener {
            stopSelf()
        }
    }

    private fun executeSingleBotMove(tvStatus: TextView) {
        val accessibilityService = CakeBotAccessibilityService.instance
        if (accessibilityService == null) {
            tvStatus.text = "Error: Accessibility Service OFF"
            return
        }

        val displayMetrics = resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels.toFloat()
        val screenHeight = displayMetrics.heightPixels.toFloat()

        // Mock detected layout mapping for demonstration screen coordinates
        val dockPositions = listOf(
            Pair(screenWidth * 0.20f, screenHeight * 0.85f),
            Pair(screenWidth * 0.40f, screenHeight * 0.85f),
            Pair(screenWidth * 0.60f, screenHeight * 0.85f),
            Pair(screenWidth * 0.80f, screenHeight * 0.85f)
        )

        val boardPositions = List(20) { idx ->
            val row = idx / 4
            val col = idx % 4
            Pair(screenWidth * (0.18f + col * 0.21f), screenHeight * (0.15f + row * 0.11f))
        }

        // Generate current board evaluation state
        val mockDock = listOf(CakePlate(0, listOf(1)), CakePlate(1, listOf(2)), null, null)
        val mockBoard = MutableList<CakePlate?>(20) { null }

        val bestMove = solverEngine.findBestMove(mockDock, mockBoard)
        if (bestMove != null) {
            val start = dockPositions[bestMove.fromDockIndex]
            val end = boardPositions[bestMove.toBoardIndex]

            tvStatus.text = "Action: Drag D${bestMove.fromDockIndex + 1} -> B${bestMove.toBoardIndex + 1}"
            accessibilityService.performDragAndDrop(
                startX = start.first,
                startY = start.second,
                endX = end.first,
                endY = end.second
            ) {
                tvStatus.text = "Status: Move Completed"
            }
        } else {
            tvStatus.text = "Status: No Move Found"
        }
    }

    private fun startAutoLoop(tvStatus: TextView) {
        autoRunnable = object : Runnable {
            override fun run() {
                if (isAutoRunning) {
                    executeSingleBotMove(tvStatus)
                    handler.postDelayed(this, 1200L)
                }
            }
        }
        handler.post(autoRunnable!!)
    }

    private fun stopAutoLoop() {
        autoRunnable?.let { handler.removeCallbacks(it) }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAutoLoop()
        if (::floatingView.isInitialized) {
            windowManager.removeView(floatingView)
        }
    }
}