package com.cakesort.bot.engine

import com.cakesort.bot.model.BotMove
import com.cakesort.bot.model.CakePlate

class CakeSolverEngine {
    private val boardCols = 4
    private val boardRows = 5
    private val boardSlotsCount = 20
    private val dockSlotsCount = 4
    private val slicesPerCake = 6

    private fun isAdjacent(idx1: Int, idx2: Int): Boolean {
        val col1 = idx1 % boardCols
        val row1 = idx1 / boardCols
        val col2 = idx2 % boardCols
        val row2 = idx2 / boardCols

        val dx = Math.abs(col1 - col2)
        val dy = Math.abs(row1 - row2)

        return (dx + dy == 1)
    }

    fun evaluateMove(
        dockIdx: Int,
        boardIdx: Int,
        dockState: List<CakePlate?>,
        boardState: List<CakePlate?>
    ): Int {
        val currentDockItem = dockState.getOrNull(dockIdx) ?: return -1000
        if (currentDockItem.flavors.isEmpty()) return -1000
        if (boardState.getOrNull(boardIdx) != null) return -1000 // Slot occupied

        var score = 0
        val targetFlavors = currentDockItem.flavors

        // Check 4-way adjacent neighbors
        for (i in 0 until boardSlotsCount) {
            val neighbor = boardState.getOrNull(i)
            if (neighbor != null && isAdjacent(boardIdx, i)) {
                val matches = targetFlavors.filter { neighbor.flavors.contains(it) }
                if (matches.isNotEmpty()) {
                    score += 80 * matches.size
                }
            }
        }

        // Penalty for isolated placement
        var emptyNeighbors = 0
        for (i in 0 until boardSlotsCount) {
            if (isAdjacent(boardIdx, i) && boardState.getOrNull(i) == null) {
                emptyNeighbors++
            }
        }
        score += emptyNeighbors * 10

        return score
    }

    fun findBestMove(
        dockState: List<CakePlate?>,
        boardState: List<CakePlate?>
    ): BotMove? {
        var bestMove: BotMove? = null
        var highestScore = -99999

        for (d in 0 until dockSlotsCount) {
            val dockItem = dockState.getOrNull(d) ?: continue
            if (dockItem.flavors.isEmpty()) continue

            for (b in 0 until boardSlotsCount) {
                if (boardState.getOrNull(b) != null) continue

                val score = evaluateMove(d, b, dockState, boardState)
                if (score > highestScore) {
                    highestScore = score
                    bestMove = BotMove(fromDockIndex = d, toBoardIndex = b, score = score)
                }
            }
        }
        return bestMove
    }
}