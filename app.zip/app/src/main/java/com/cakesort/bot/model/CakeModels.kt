package com.cakesort.bot.model

data class SlotPoint(val x: Float, val y: Float)

data class CakePlate(
    val slotIndex: Int,
    val flavors: List<Int>
)

data class BotMove(
    val fromDockIndex: Int,
    val toBoardIndex: Int,
    val score: Int
)

enum class BotMode {
    MANUAL,
    STEP,
    AUTO
}