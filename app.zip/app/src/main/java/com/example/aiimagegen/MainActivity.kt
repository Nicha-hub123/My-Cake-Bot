package com.example.aiimagegen

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Callback
import com.squareup.picasso.Picasso
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    private lateinit var etPrompt: EditText
    private lateinit var btnGenerate: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var ivResult: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etPrompt = findViewById(R.id.etPrompt)
        btnGenerate = findViewById(R.id.btnGenerate)
        progressBar = findViewById(R.id.progressBar)
        ivResult = findViewById(R.id.ivResult)

        btnGenerate.setOnClickListener {
            val prompt = etPrompt.text.toString().trim()
            if (prompt.isNotEmpty()) {
                generateImage(prompt)
            } else {
                Toast.makeText(this, "Please enter a prompt", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun generateImage(prompt: String) {
        progressBar.visibility = View.VISIBLE
        btnGenerate.isEnabled = false

        val encodedPrompt = URLEncoder.encode(prompt, "UTF-8")
        val imageUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=1024&height=1024&nologo=true"

        Picasso.get()
            .load(imageUrl)
            .into(ivResult, object : Callback {
                override fun onSuccess() {
                    progressBar.visibility = View.GONE
                    btnGenerate.isEnabled = true
                }

                override fun onError(e: Exception?) {
                    progressBar.visibility = View.GONE
                    btnGenerate.isEnabled = true
                    Toast.makeText(this@MainActivity, "Failed to generate image", Toast.LENGTH_SHORT).show()
                }
            })
    }
}