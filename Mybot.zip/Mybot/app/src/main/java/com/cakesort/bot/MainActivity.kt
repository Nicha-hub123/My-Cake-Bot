package com.cakesort.bot

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.cakesort.bot.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun setupListeners() {
        binding.btnPermission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay permission already granted", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnStart.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Bot Assistant Service Ready", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please grant Overlay Permission first", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun updateStatus() {
        val hasOverlay = Settings.canDrawOverlays(this)
        if (hasOverlay) {
            binding.tvStatus.text = "Status: Active & Ready"
            binding.tvStatusDetails.text = "All required permissions are granted."
            binding.btnPermission.isEnabled = false
            binding.btnPermission.alpha = 0.5f
        } else {
            binding.tvStatus.text = "Status: Action Required"
            binding.tvStatusDetails.text = "Display overlay permission is required."
            binding.btnPermission.isEnabled = true
            binding.btnPermission.alpha = 1.0f
        }
    }
}